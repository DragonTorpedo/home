# AI Master — Dream Homepage

AI Master is a responsive, interactive homepage for a living AI decision engine. It helps visitors move from “Which AI is best?” to “Which AI fits my work, budget, ecosystem, and priorities right now?”

## What is included

- Premium Intelligence Compass hero
- Interactive map for OpenAI, Anthropic, Google, Kimi, Z.AI, DeepSeek, and xAI
- Task-based entry points
- Eight-step Quick Match survey
- Deterministic recommendation logic with different results for different profiles
- Personalized match result with reasons and limitations
- Provider ecosystem cards
- AI Market Pulse
- Use-case explorer
- Methodology and independence sections
- Responsive desktop, tablet, and mobile layouts
- Keyboard navigation and reduced-motion support
- GitHub Pages deployment workflow

## Run locally

Install Node.js 22 or newer, then run:

```bash
npm install
npm run dev
```

Open the local address shown in the terminal.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Copy every file from this project into the repository.
3. Push the files to the `main` branch.
4. In the GitHub repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **GitHub Actions**.
6. Open the **Actions** tab and allow the “Deploy AI Master to GitHub Pages” workflow to finish.

The included workflow automatically detects the repository name and configures the correct asset path for project Pages sites such as `username.github.io/repository-name/`.

## Production content note

AI model names, product access, availability, pricing, and evaluation results change frequently. The homepage contains curated demonstration records. Before a public decision platform launch, connect these records to a dated editorial data source and verify every current product claim.

## Main source files

- `app/page.tsx` — homepage content, interactions, survey, and recommendation logic
- `app/globals.css` — complete visual system and responsive layout
- `app/layout.tsx` — page metadata and global shell
- `.github/workflows/deploy-pages.yml` — automated GitHub Pages publishing

## Customize

The working name “AI Master” can be replaced globally after final brand and domain research. The provider, task, survey, use-case, and market-update data are centralized near the top of `app/page.tsx` for straightforward editing.
