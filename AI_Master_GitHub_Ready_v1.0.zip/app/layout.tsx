import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const pagesRepository = process.env.GITHUB_REPOSITORY?.split("/")[1] ?? "";
const pagesBasePath =
  process.env.GITHUB_PAGES === "true" &&
  pagesRepository &&
  !pagesRepository.endsWith(".github.io")
    ? `/${pagesRepository}`
    : "";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AI Master — Find the right AI for the way you work",
  description: "A personalized AI decision engine for finding the right tools, products, and workflows for your work.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: `${pagesBasePath}/favicon.svg`,
    shortcut: `${pagesBasePath}/favicon.svg`,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
