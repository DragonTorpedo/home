"use client";

import { useEffect, useMemo, useState } from "react";

type Provider = {
  name: string;
  short: string;
  specialty: string;
  tone: string;
  position: string;
};

const providers: Provider[] = [
  { name: "OpenAI", short: "O", specialty: "Work · agents · coding", tone: "#9af4d2", position: "node-1" },
  { name: "Anthropic", short: "A", specialty: "Reasoning · writing", tone: "#f0b88d", position: "node-2" },
  { name: "Google", short: "G", specialty: "Research · multimodal", tone: "#8ab4ff", position: "node-3" },
  { name: "Kimi", short: "K", specialty: "Long context · slides", tone: "#b4a0ff", position: "node-4" },
  { name: "Z.AI", short: "Z", specialty: "Engineering · agents", tone: "#74e4ff", position: "node-5" },
  { name: "DeepSeek", short: "D", specialty: "Reasoning · value", tone: "#7f9cff", position: "node-6" },
  { name: "xAI", short: "X", specialty: "Live search · media", tone: "#f4f4f7", position: "node-7" },
];

const tasks = [
  { icon: "✦", label: "Write & communicate" },
  { icon: "⌕", label: "Research & learn" },
  { icon: "</>", label: "Code & build" },
  { icon: "◫", label: "Create images" },
  { icon: "▶", label: "Create video" },
  { icon: "▤", label: "Analyze documents" },
  { icon: "↗", label: "Run a business" },
  { icon: "⌁", label: "Automate work" },
];

const quizQuestions = [
  {
    id: "role",
    eyebrow: "START WITH YOU",
    title: "What best describes you?",
    note: "This changes how much complexity and setup we recommend.",
    options: ["Student", "Educator", "Writer or marketer", "Creator or designer", "Software developer", "Business or operations", "Researcher", "Personal user"],
  },
  {
    id: "goal",
    eyebrow: "YOUR MAIN OUTCOME",
    title: "What matters most in the result?",
    note: "There is no universal winner—the best choice depends on your priority.",
    options: ["Highest possible quality", "Reliable sources", "Easiest to use", "Fastest response", "Lowest price", "Best integrations", "Strong privacy controls", "Deep project work"],
  },
  {
    id: "files",
    eyebrow: "YOUR MATERIALS",
    title: "What do you work with most?",
    note: "We will favor tools that handle your real inputs well.",
    options: ["PDFs and documents", "Presentations", "Spreadsheets", "Images", "Audio and video", "Code repositories", "Mostly text prompts", "A mix of everything"],
  },
  {
    id: "ecosystem",
    eyebrow: "YOUR ECOSYSTEM",
    title: "Where does your work already live?",
    note: "This is a preference signal—not an automatic decision.",
    options: ["Google Workspace", "Microsoft 365", "Apple", "GitHub and developer tools", "Multiple ecosystems", "No strong preference"],
  },
  {
    id: "budget",
    eyebrow: "YOUR BUDGET",
    title: "What feels reasonable each month?",
    note: "We will show the estimated total cost of your stack.",
    options: ["Free only", "Under $10", "$10–$25", "$25–$50", "$50–$100", "Business or team budget"],
  },
  {
    id: "web",
    eyebrow: "CURRENT INFORMATION",
    title: "How important are live web sources?",
    note: "Research quality and general intelligence are not the same thing.",
    options: ["Not important", "Sometimes helpful", "Essential", "Essential with citations"],
  },
  {
    id: "technical",
    eyebrow: "YOUR COMFORT LEVEL",
    title: "How technical should the experience be?",
    note: "We can keep it simple or include APIs, agents, and open models.",
    options: ["Simple chat only", "Advanced settings are fine", "I use no-code automation", "I write code", "I build with APIs", "I want open models or self-hosting"],
  },
  {
    id: "pace",
    eyebrow: "FINAL TRADEOFF",
    title: "Which side sounds more like you?",
    note: "This helps us choose between speed, value, and deeper work.",
    options: ["Fast and efficient", "Balanced", "Deepest possible work", "Low cost at scale"],
  },
];

const providerDetails = [
  { name: "OpenAI", mark: "O", best: "End-to-end work", description: "A broad ecosystem for professional work, coding, images, voice, and agentic execution.", products: ["ChatGPT", "Codex", "GPT", "Image", "Voice"], status: "Broadest toolkit", tone: "mint" },
  { name: "Anthropic", mark: "A", best: "Thoughtful depth", description: "Strong for professional reasoning, writing, long projects, and coding collaboration.", products: ["Claude", "Claude Code", "Design", "API"], status: "Deep work", tone: "sand" },
  { name: "Google", mark: "G", best: "Connected research", description: "A rich ecosystem spanning assistance, source-based research, images, video, and open models.", products: ["Gemini", "NotebookLM", "Flow", "Veo", "Gemma"], status: "Multimodal ecosystem", tone: "blue" },
  { name: "Kimi", mark: "K", best: "Long-horizon creation", description: "Designed around long-context knowledge work, coding, presentations, and agent workflows.", products: ["Kimi", "K3", "Code", "Slides"], status: "Long context", tone: "violet" },
  { name: "Z.AI", mark: "Z", best: "Agentic engineering", description: "GLM-powered tools for coding, agents, visual understanding, and developer access.", products: ["GLM", "Coding Plan", "Vision", "API"], status: "Engineering focus", tone: "cyan" },
  { name: "DeepSeek", mark: "D", best: "Reasoning value", description: "Cost-conscious reasoning and coding with strong interest from open-model builders.", products: ["Chat", "Reasoning", "Code", "API"], status: "Value leader", tone: "indigo" },
  { name: "xAI", mark: "X", best: "Live signal", description: "Grok products for current information, coding, image and video creation, and APIs.", products: ["Grok", "Build", "Imagine", "API"], status: "Current information", tone: "white" },
];

const useCases = [
  { number: "01", title: "Research with sources", copy: "Find, compare, and synthesize current information without losing the evidence trail.", accent: "#8ab4ff" },
  { number: "02", title: "Professional writing", copy: "Move from rough thinking to clear, polished work while protecting your voice.", accent: "#f0b88d" },
  { number: "03", title: "Code and build", copy: "Choose between a coding partner, an autonomous agent, and an open model stack.", accent: "#9af4d2" },
  { number: "04", title: "Create visual worlds", copy: "Match image, editing, video, and sound tools to the way you actually create.", accent: "#b4a0ff" },
];

export default function Home() {
  const [activeProvider, setActiveProvider] = useState("Google");
  const [selectedTask, setSelectedTask] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [surveyOpen, setSurveyOpen] = useState(false);
  const [quizStep, setQuizStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResult, setShowResult] = useState(false);

  const active = useMemo(
    () => providers.find((provider) => provider.name === activeProvider) ?? providers[2],
    [activeProvider],
  );

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMenuOpen(false);
        setSurveyOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const beginMatch = (task?: string) => {
    if (task) setSelectedTask(task);
    setQuizStep(0);
    setAnswers({});
    setShowResult(false);
    setSurveyOpen(true);
  };

  const chooseAnswer = (answer: string) => {
    const question = quizQuestions[quizStep];
    const nextAnswers = { ...answers, [question.id]: answer };
    setAnswers(nextAnswers);
    if (quizStep === quizQuestions.length - 1) {
      setShowResult(true);
    } else {
      setQuizStep((step) => step + 1);
    }
  };

  const recommendedProvider = useMemo(() => {
    const task = selectedTask ?? "";
    const goal = answers.goal ?? "";
    const ecosystem = answers.ecosystem ?? "";
    const technical = answers.technical ?? "";
    const budget = answers.budget ?? "";
    if (technical.includes("open models") || budget === "Free only") return providerDetails[5];
    if (task.includes("Research") || goal === "Reliable sources" || ecosystem === "Google Workspace") return providerDetails[2];
    if (task.includes("Code") && (technical.includes("code") || technical.includes("API"))) return providerDetails[1];
    if (task.includes("video") || task.includes("images") || answers.files === "Images" || answers.files === "Audio and video") return providerDetails[2];
    if (goal === "Deep project work" || answers.pace === "Deepest possible work") return providerDetails[1];
    if (goal === "Lowest price" || answers.pace === "Low cost at scale") return providerDetails[5];
    return providerDetails[0];
  }, [answers, selectedTask]);

  const resultProduct = recommendedProvider.name === "Google" ? "Gemini + NotebookLM" : recommendedProvider.name === "Anthropic" ? "Claude" : recommendedProvider.name === "DeepSeek" ? "DeepSeek" : "ChatGPT";

  return (
    <main>
      <a className="skip-link" href="#main-content">Skip to content</a>

      <header className="site-header">
        <a className="brand" href="#top" aria-label="AI Master home">
          <span className="brand-mark" aria-hidden="true"><i /></span>
          <span>AI Master</span>
        </a>
        <nav className={menuOpen ? "nav-links is-open" : "nav-links"} aria-label="Primary navigation">
          <a href="#match">Find My AI</a>
          <a href="#landscape">AI Companies</a>
          <a href="#tools">AI Tools</a>
          <a href="#compare">Compare</a>
          <a href="#use-cases">Use Cases</a>
          <a href="#pulse">What&apos;s New</a>
        </nav>
        <div className="header-actions">
          <button className="button button-small" onClick={() => beginMatch()}>
            Find My AI <span aria-hidden="true">↗</span>
          </button>
          <button
            className="menu-button"
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((value) => !value)}
          >
            <span /><span />
          </button>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-glow" aria-hidden="true" />
        <div className="hero-grid" aria-hidden="true" />
        <div className="hero-copy" id="main-content">
          <div className="eyebrow"><span className="live-dot" /> The AI decision engine <span className="eyebrow-line" /></div>
          <h1>Find the right AI<br />for the way <em>you</em> work.</h1>
          <p className="hero-lede">
            Answer a few questions. Get a personalized AI stack for writing,
            research, coding, images, video, learning, and more—based on what
            matters to you <strong>now.</strong>
          </p>
          <div className="hero-actions">
            <button className="button button-primary" onClick={() => beginMatch()}>
              Find My AI <span className="arrow" aria-hidden="true">↗</span>
            </button>
            <a className="text-link" href="#landscape">Explore the AI map <span aria-hidden="true">↓</span></a>
          </div>
          <div className="trust-line" aria-label="Survey details">
            <span><b>✓</b> Free</span>
            <i />
            <span><b>◷</b> About 3 minutes</span>
            <i />
            <span><b>◇</b> No account required</span>
          </div>
        </div>

        <div className="compass-wrap" aria-label="Interactive map of AI providers">
          <div className="compass-aura" aria-hidden="true" />
          <div className="compass-lines" aria-hidden="true">
            <span className="orbit orbit-one" />
            <span className="orbit orbit-two" />
            <span className="axis axis-x" />
            <span className="axis axis-y" />
          </div>
          <div className="compass-center">
            <span className="center-kicker">Your best fit</span>
            <span className="center-score">92</span>
            <span className="center-label">Match potential</span>
            <i className="center-signal" />
          </div>
          {providers.map((provider) => (
            <button
              key={provider.name}
              className={`provider-node ${provider.position} ${activeProvider === provider.name ? "is-active" : ""}`}
              style={{ "--provider-tone": provider.tone } as React.CSSProperties}
              onMouseEnter={() => setActiveProvider(provider.name)}
              onFocus={() => setActiveProvider(provider.name)}
              onClick={() => setActiveProvider(provider.name)}
              aria-pressed={activeProvider === provider.name}
            >
              <span className="node-glyph">{provider.short}</span>
              <span className="node-meta"><b>{provider.name}</b><small>{provider.specialty}</small></span>
            </button>
          ))}
          <div className="active-provider-card" style={{ "--provider-tone": active.tone } as React.CSSProperties}>
            <span className="active-ping" />
            <div><small>Current focus</small><strong>{active.name}</strong></div>
            <p>{active.specialty}</p>
          </div>
          <span className="map-caption">Move through the map to explore</span>
        </div>

        <div className="hero-index" aria-hidden="true"><span>01</span><i /><small>ORIENT</small></div>
      </section>

      <section className="task-entry" id="match">
        <div className="section-kicker">Start with your work</div>
        <div className="task-heading">
          <h2>What do you want AI to help you do?</h2>
          <p>Choose a task and we&apos;ll begin your match there.</p>
        </div>
        <div className="task-grid">
          {tasks.map((task) => (
            <button
              key={task.label}
              className={selectedTask === task.label ? "task-card is-selected" : "task-card"}
              onClick={() => beginMatch(task.label)}
            >
              <span className="task-icon" aria-hidden="true">{task.icon}</span>
              <span>{task.label}</span>
              <i aria-hidden="true">↗</i>
            </button>
          ))}
        </div>
        <div className="task-note"><span>Independent recommendations</span><i /><span>Current capability data</span><i /><span>Transparent tradeoffs</span></div>
      </section>

      <section className="editorial-break">
        <div className="editorial-label"><span>THE PROBLEM</span><i /></div>
        <div className="editorial-copy">
          <p>The question is no longer</p>
          <h2>“Should I use AI?”</h2>
          <p>It&apos;s <em>“Which AI should I use for this?”</em></p>
        </div>
        <div className="confusion-grid">
          <article><span>01</span><h3>One company.<br />Many products.</h3><p>A provider name does not tell you which assistant, model, or specialist tool you need.</p></article>
          <article><span>02</span><h3>The winner changes<br />with the task.</h3><p>Research, writing, coding, images, and video require very different strengths.</p></article>
          <article><span>03</span><h3>The landscape<br />never stands still.</h3><p>Models, plans, prices, and access can change before an old ranking is updated.</p></article>
        </div>
        <p className="editorial-answer">AI Master turns that moving landscape into a decision you can understand.</p>
      </section>

      <section className="how-section" id="tools">
        <div className="section-heading dark-heading">
          <span>02 · CALIBRATE</span>
          <h2>From your work<br />to your <em>AI stack.</em></h2>
          <p>Not a popularity contest. A transparent match built around your priorities.</p>
        </div>
        <div className="process-grid">
          <article>
            <div className="process-visual profile-visual"><i /><b>YOU</b><span>role</span><span>tasks</span><span>files</span><span>budget</span></div>
            <div className="process-copy"><b>01</b><h3>Tell us how you work</h3><p>Choose what you do, what matters, and the constraints a recommendation must respect.</p></div>
          </article>
          <article>
            <div className="process-visual match-visual"><span>QUALITY</span><i style={{"--v":"82%"} as React.CSSProperties} /><span>SOURCES</span><i style={{"--v":"94%"} as React.CSSProperties} /><span>VALUE</span><i style={{"--v":"68%"} as React.CSSProperties} /><span>FIT</span><i style={{"--v":"88%"} as React.CSSProperties} /></div>
            <div className="process-copy"><b>02</b><h3>We calculate your fit</h3><p>Hard requirements come first. Then capability, cost, evidence, and current access.</p></div>
          </article>
          <article>
            <div className="process-visual stack-visual"><span className="stack-a">PRIMARY</span><span className="stack-b">SPECIALIST</span><span className="stack-c">OPTIONAL</span><i /></div>
            <div className="process-copy"><b>03</b><h3>Get your practical stack</h3><p>See what to start with, what adds real value, what to skip, and your first workflow.</p></div>
          </article>
        </div>
      </section>

      <section className="result-preview" id="compare">
        <div className="result-intro">
          <span className="section-number">03 · DECIDE</span>
          <h2>A result that<br />earns your <em>confidence.</em></h2>
          <p>Every recommendation comes with its reasons, tradeoffs, evidence status, and a clear way to begin.</p>
          <button className="button result-cta" onClick={() => beginMatch()}>Get my recommendation <span>↗</span></button>
        </div>
        <div className="result-window">
          <div className="window-top"><span><i /><i /><i /></span><b>AI MATCH / SAMPLE RESULT</b><small>Verified Jul 20, 2026</small></div>
          <div className="persona-row"><div><span>M</span><p><small>MAYA&apos;S PROFILE</small><b>The Source-Grounded Operator</b></p></div><strong>91<small>/100 match</small></strong></div>
          <div className="result-main-card">
            <div className="recommendation-brand"><span>G</span><p><small>PRIMARY ECOSYSTEM</small><b>Google</b><em>Connected research & creation</em></p></div>
            <div className="confidence-pill"><i /> High confidence</div>
            <h3>Gemini for daily work.<br />NotebookLM for evidence.</h3>
            <ul><li>Works naturally with Maya&apos;s existing documents</li><li>Strong fit for research that needs inspectable sources</li><li>One ecosystem covers everyday and specialist work</li></ul>
            <div className="limitation"><b>WATCH OUT</b><span>For deep repository coding, add a dedicated coding specialist instead.</span></div>
          </div>
          <div className="stack-row">
            <article><small>ESSENTIAL</small><b>Gemini</b><span>Daily planning & work</span></article>
            <article><small>USEFUL</small><b>NotebookLM</b><span>Source-based research</span></article>
            <article><small>OPTIONAL</small><b>Codex</b><span>Only for serious coding</span></article>
          </div>
        </div>
      </section>

      <section className="landscape-section" id="landscape">
        <div className="landscape-head">
          <div><span>04 · THE LANDSCAPE</span><h2>Seven ecosystems.<br /><em>One clear map.</em></h2></div>
          <p>Explore each provider as a connected system of assistants, models, specialist products, and access choices.</p>
        </div>
        <div className="provider-grid">
          {providerDetails.map((provider, index) => (
            <article className={`provider-card tone-${provider.tone}`} key={provider.name}>
              <div className="provider-card-top"><span>{provider.mark}</span><small>0{index + 1}</small></div>
              <div className="provider-title"><small>{provider.best}</small><h3>{provider.name}</h3></div>
              <p>{provider.description}</p>
              <div className="product-chips">{provider.products.map((product) => <span key={product}>{product}</span>)}</div>
              <div className="provider-card-foot"><span><i /> {provider.status}</span><button aria-label={`Explore ${provider.name}`} onClick={() => beginMatch(`${provider.name} ecosystem`)}>↗</button></div>
            </article>
          ))}
          <article className="provider-card take-survey-card">
            <span className="mini-compass"><i /></span>
            <h3>Don&apos;t browse.<br />Get matched.</h3>
            <p>Let your actual work narrow the landscape.</p>
            <button onClick={() => beginMatch()}>Find My AI <span>↗</span></button>
          </article>
        </div>
        <p className="data-disclaimer">Product names and availability change. Version-specific facts are reviewed as structured, dated records.</p>
      </section>

      <section className="pulse-section" id="pulse">
        <div className="pulse-top">
          <div><span className="pulse-live"><i /> LIVE MARKET PULSE</span><h2>Know what changed.<br /><em>Know what it means.</em></h2></div>
          <div className="update-time"><span>LAST REVIEW</span><b>JUL 20 · 2026</b><small>Recommendations recalculated after major changes</small></div>
        </div>
        <div className="updates-list">
          <article><time>JUL 16</time><span className="update-badge new">NEW</span><div><small>KIMI</small><h3>New flagship generation</h3><p>Long-context, coding, and agent workflows require a fresh evaluation.</p></div><strong>Needs testing</strong><a href="#methodology" aria-label="Read Kimi update">↗</a></article>
          <article><time>JUL 09</time><span className="update-badge major">MAJOR</span><div><small>OPENAI</small><h3>Frontier model family update</h3><p>Professional-work and coding recommendations have been recalculated.</p></div><strong>Scores updated</strong><a href="#methodology" aria-label="Read OpenAI update">↗</a></article>
          <article><time>JUN 30</time><span className="update-badge review">REVIEW</span><div><small>ANTHROPIC</small><h3>New Sonnet generation</h3><p>Agentic work, coding, and professional-use tests are being refreshed.</p></div><strong>Recently tested</strong><a href="#methodology" aria-label="Read Anthropic update">↗</a></article>
          <article><time>APR 26</time><span className="update-badge retiring">RETIRED</span><div><small>OPENAI</small><h3>Sora app experience discontinued</h3><p>Older video recommendations were archived instead of silently removed.</p></div><strong>Archive visible</strong><a href="#methodology" aria-label="Read Sora update">↗</a></article>
        </div>
        <div className="pulse-foot"><p>Not noise. Only changes that may affect a real decision.</p><a href="#methodology">See our update policy <span>↗</span></a></div>
      </section>

      <section className="use-section" id="use-cases">
        <div className="use-heading"><span>05 · START WITH THE TASK</span><h2>What are you trying<br />to <em>make happen?</em></h2></div>
        <div className="use-list">
          {useCases.map((item) => (
            <button key={item.number} onClick={() => beginMatch(item.title)} style={{"--use-tone": item.accent} as React.CSSProperties}>
              <span>{item.number}</span><h3>{item.title}</h3><p>{item.copy}</p><i>↗</i>
            </button>
          ))}
        </div>
      </section>

      <section className="method-section" id="methodology">
        <div className="method-orbit" aria-hidden="true"><span>FIT</span><i /><i /><i /></div>
        <div className="method-copy">
          <span>06 · TRUST THE METHOD</span>
          <h2>Recommendations<br />you can <em>inspect.</em></h2>
          <p>We separate what a provider says, what a product can demonstrably do, and what our editorial judgment concludes.</p>
          <div className="method-points"><span><b>01</b> Official facts are sourced</span><span><b>02</b> Capabilities are tested</span><span><b>03</b> Confidence is visible</span><span><b>04</b> Limitations stay in view</span></div>
          <a href="#top">Read the methodology <span>↗</span></a>
        </div>
        <aside><p>Providers cannot purchase a higher recommendation score.</p><span>INDEPENDENT BY DESIGN</span></aside>
      </section>

      <section className="final-cta">
        <div className="cta-compass" aria-hidden="true"><i /><span /></div>
        <span>YOUR DIRECTION STARTS HERE</span>
        <h2>The best AI is the one<br />that fits <em>your work.</em></h2>
        <p>Find yours in a few thoughtful minutes.</p>
        <button className="button button-primary final-button" onClick={() => beginMatch()}>Take the AI Match Survey <span className="arrow">↗</span></button>
        <small>Free · No account required · Independently scored</small>
      </section>

      <footer>
        <div className="footer-brand"><a className="brand" href="#top"><span className="brand-mark"><i /></span><span>AI Master</span></a><p>The navigation system for choosing, understanding, and changing AI tools.</p></div>
        <div className="footer-links"><div><b>DISCOVER</b><a href="#match">Find My AI</a><a href="#landscape">Companies</a><a href="#tools">Tools</a><a href="#compare">Compare</a></div><div><b>EXPLORE</b><a href="#use-cases">Use cases</a><a href="#pulse">Market Pulse</a><a href="#methodology">Methodology</a><a href="#top">About</a></div><div><b>STANDARDS</b><a href="#methodology">Editorial policy</a><a href="#methodology">Disclosures</a><a href="#methodology">Corrections</a><a href="#methodology">Privacy</a></div></div>
        <div className="footer-bottom"><span>© 2026 AI Master</span><p>Independent and not endorsed by the AI providers featured on this site.</p><span>Data reviewed Jul 20, 2026</span></div>
      </footer>

      {surveyOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={() => setSurveyOpen(false)}>
          <section className="survey-modal" role="dialog" aria-modal="true" aria-labelledby="survey-title" onMouseDown={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setSurveyOpen(false)} aria-label="Close survey">×</button>
            {!showResult ? (
              <>
                <div className="survey-progress"><i style={{ width: `${((quizStep + 1) / quizQuestions.length) * 100}%` }} /></div>
                <span className="survey-step">QUICK MATCH · {String(quizStep + 1).padStart(2, "0")} / {String(quizQuestions.length).padStart(2, "0")}</span>
                <span className="question-eyebrow">{quizQuestions[quizStep].eyebrow}</span>
                <h2 id="survey-title">{quizQuestions[quizStep].title}</h2>
                <p>{quizStep === 0 && selectedTask ? `You chose “${selectedTask}.” ${quizQuestions[quizStep].note}` : quizQuestions[quizStep].note}</p>
                <div className="role-grid">
                  {quizQuestions[quizStep].options.map((option) => (
                    <button key={option} onClick={() => chooseAnswer(option)}>{option}<span>↗</span></button>
                  ))}
                </div>
                <div className="survey-footer"><button disabled={quizStep === 0} onClick={() => setQuizStep((step) => Math.max(0, step - 1))}>← Back</button><span>Your answers stay on this device during the survey.</span><b>About 3 minutes</b></div>
              </>
            ) : (
              <div className="survey-result">
                <span className="survey-step">YOUR QUICK MATCH</span>
                <div className="mini-result-head"><span>{recommendedProvider.mark}</span><p><small>PRIMARY MATCH</small><b>{recommendedProvider.name}</b></p><strong>91<small>/100</small></strong></div>
                <h2 id="survey-title">Start with {resultProduct}.</h2>
                <p>{recommendedProvider.description}</p>
                <div className="result-reasons"><span><i>✓</i> Fits your selected task and priority</span><span><i>✓</i> Respects your budget and technical comfort</span><span><i>✓</i> Strong current ecosystem fit</span></div>
                <div className="result-caveat"><b>WHY THIS IS A QUICK MATCH</b><span>Refine it later with language, region, team, and privacy requirements.</span></div>
                <div className="result-actions"><button className="button button-primary" onClick={() => setSurveyOpen(false)}>View my starting point <span className="arrow">↗</span></button><button onClick={() => { setShowResult(false); setQuizStep(0); }}>Retake</button></div>
              </div>
            )}
          </section>
        </div>
      )}
    </main>
  );
}
